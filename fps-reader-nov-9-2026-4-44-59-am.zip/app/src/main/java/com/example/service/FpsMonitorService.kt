package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.FpsPreferences
import com.example.model.FpsTelemetry
import com.example.model.OverlayConfig
import com.example.monitor.PerformanceCollector
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class FpsMonitorService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var notificationManager: NotificationManager
    private lateinit var prefs: FpsPreferences
    private lateinit var collector: PerformanceCollector

    private var overlayView: View? = null
    private var windowParams: WindowManager.LayoutParams? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private var telemetryJob: Job? = null
    private var notificationJob: Job? = null

    // Overlay View Elements
    private var fpsTextView: TextView? = null
    private var detailTextView: TextView? = null
    private var statusDot: View? = null
    private var dragLockIndicator: ImageView? = null
    private var containerLayout: LinearLayout? = null

    private var currentConfig = OverlayConfig()
    private var currentTelemetry = FpsTelemetry()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        prefs = FpsPreferences.getInstance(this)
        collector = PerformanceCollector.getInstance(this)

        createNotificationChannel()
        collector.start()

        observeConfig()
        observeTelemetry()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.fps_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.fps_channel_desc)
                setShowBadge(false)
                enableLights(false)
                enableVibration(false)
                setSound(null, null)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun observeConfig() {
        serviceScope.launch {
            prefs.configFlow.collectLatest { config ->
                currentConfig = config
                handleConfigChange(config)
            }
        }
    }

    private fun observeTelemetry() {
        telemetryJob = serviceScope.launch {
            collector.telemetryFlow.collectLatest { telemetry ->
                currentTelemetry = telemetry
                updateOverlayContent(telemetry)
            }
        }

        // Notification update throttled to 1s to ensure ultra-low battery consumption
        notificationJob = serviceScope.launch {
            while (true) {
                delay(1000L)
                if (currentConfig.isNotificationEnabled) {
                    val notif = buildNotification(currentTelemetry, currentConfig)
                    notificationManager.notify(NOTIFICATION_ID, notif)
                }
            }
        }
    }

    private fun handleConfigChange(config: OverlayConfig) {
        // If neither overlay nor notification is enabled, stop service
        if (!config.isOverlayEnabled && !config.isNotificationEnabled) {
            stopSelf()
            return
        }

        // Update Foreground Notification
        val notif = buildNotification(currentTelemetry, config)
        startForeground(NOTIFICATION_ID, notif)

        // Manage Floating Window
        if (config.isOverlayEnabled) {
            if (Settings.canDrawOverlays(this)) {
                if (overlayView == null) {
                    showOverlay(config)
                } else {
                    updateOverlayWindowParams(config)
                    applyOverlayStyle(config)
                }
            }
        } else {
            removeOverlay()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOverlay(config: OverlayConfig) {
        if (overlayView != null) return

        // Create programmatic lightweight overlay view
        val context = this
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dpToPx(10), dpToPx(6), dpToPx(10), dpToPx(6))
        }
        containerLayout = root

        // Header Row: Dot + FPS text + Lock Icon
        val topRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dot = View(context).apply {
            val size = dpToPx(8)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = dpToPx(6)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#39FF14"))
            }
        }
        statusDot = dot
        topRow.addView(dot)

        val fpsText = TextView(context).apply {
            textSize = 15f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            text = "60 FPS"
        }
        fpsTextView = fpsText
        topRow.addView(fpsText)

        // Drag/Lock icon (visible only when unlocked to drag)
        val lockIcon = ImageView(context).apply {
            val size = dpToPx(14)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginStart = dpToPx(8)
            }
            setImageResource(android.R.drawable.ic_lock_lock)
            setColorFilter(Color.parseColor("#00F0FF"))
            visibility = if (config.isTouchThroughEnabled) View.GONE else View.VISIBLE
            setOnClickListener {
                // Clicking the lock icon immediately locks into touch-through mode
                prefs.setTouchThroughEnabled(true)
            }
        }
        dragLockIndicator = lockIcon
        topRow.addView(lockIcon)

        root.addView(topRow)

        // Detail Row (for expanded mode: Hz, RAM, Temp)
        val detailText = TextView(context).apply {
            textSize = 10f
            typeface = android.graphics.Typeface.MONOSPACE
            setTextColor(Color.parseColor("#A0AEC0"))
            text = "60Hz • RAM 45% • 34°C"
            visibility = if (config.isCompactMode) View.GONE else View.VISIBLE
            setPadding(0, dpToPx(3), 0, 0)
        }
        detailTextView = detailText
        root.addView(detailText)

        // Setup Drag Listener
        setupTouchListener(root)

        // Calculate Window Layout Flags
        val flags = calculateWindowFlags(config)

        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = config.posX
            y = config.posY
        }
        windowParams = params

        applyOverlayStyle(config)

        try {
            windowManager.addView(root, params)
            overlayView = root
        } catch (_: Exception) {
            overlayView = null
        }
    }

    private fun calculateWindowFlags(config: OverlayConfig): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        // CRITICAL FOR USER REQUIREMENT:
        // When isTouchThroughEnabled is TRUE, add FLAG_NOT_TOUCHABLE.
        // Touches pass 100% straight through to the underlying game/screen with ZERO interference!
        if (config.isTouchThroughEnabled) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        return flags
    }

    private fun updateOverlayWindowParams(config: OverlayConfig) {
        val view = overlayView ?: return
        val params = windowParams ?: return

        val newFlags = calculateWindowFlags(config)
        if (params.flags != newFlags || params.x != config.posX || params.y != config.posY) {
            params.flags = newFlags
            params.x = config.posX
            params.y = config.posY
            try {
                windowManager.updateViewLayout(view, params)
            } catch (_: Exception) {}
        }

        dragLockIndicator?.visibility = if (config.isTouchThroughEnabled) View.GONE else View.VISIBLE
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchListener(view: View) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isMoving = false

        view.setOnTouchListener { _, event ->
            // If touch-through is enabled, touch listener shouldn't even be called,
            // but just in case check flag:
            if (currentConfig.isTouchThroughEnabled) {
                return@setOnTouchListener false
            }

            val params = windowParams ?: return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isMoving = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaX = (event.rawX - initialTouchX).toInt()
                    val deltaY = (event.rawY - initialTouchY).toInt()

                    if (Math.abs(deltaX) > 5 || Math.abs(deltaY) > 5) {
                        isMoving = true
                    }

                    params.x = initialX + deltaX
                    params.y = initialY + deltaY
                    try {
                        windowManager.updateViewLayout(view, params)
                    } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isMoving) {
                        prefs.setPosition(params.x, params.y)
                    } else {
                        // Tapped while unlocked: switch between compact and expanded
                        prefs.setCompactMode(!currentConfig.isCompactMode)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun applyOverlayStyle(config: OverlayConfig) {
        val root = containerLayout ?: return
        val accentHex = when (config.accentColor) {
            "LIME" -> "#39FF14"
            "RED" -> "#FF3366"
            "YELLOW" -> "#FFD600"
            "PURPLE" -> "#A855F7"
            else -> "#00F0FF" // CYAN
        }
        val accentColorInt = Color.parseColor(accentHex)

        // Cyberpunk translucent HUD background
        val alphaInt = (config.opacity.coerceIn(0.2f, 1.0f) * 255).toInt()
        val bgDrawable = GradientDrawable().apply {
            cornerRadius = dpToPx(16).toFloat()
            setColor(Color.argb(alphaInt, 10, 14, 23)) // Dark obsidian gamer surface
            setStroke(dpToPx(1), accentColorInt)
        }
        root.background = bgDrawable

        fpsTextView?.setTextColor(accentColorInt)
        detailTextView?.visibility = if (config.isCompactMode) View.GONE else View.VISIBLE
    }

    private fun updateOverlayContent(telemetry: FpsTelemetry) {
        val fps = telemetry.currentFps
        fpsTextView?.text = "$fps FPS"

        // Dynamic status dot color based on frame rate stability
        val dotColor = when {
            fps >= (telemetry.targetRefreshRate - 3) -> Color.parseColor("#39FF14") // Green
            fps >= (telemetry.targetRefreshRate * 0.75f) -> Color.parseColor("#FFD600") // Yellow
            else -> Color.parseColor("#FF3366") // Red drop
        }
        (statusDot?.background as? GradientDrawable)?.setColor(dotColor)

        if (!currentConfig.isCompactMode) {
            val text = "${telemetry.targetRefreshRate}Hz • RAM ${telemetry.ramUsagePercent}% • ${telemetry.batteryTempCelsius.toInt()}°C"
            detailTextView?.text = text
        }
    }

    private fun removeOverlay() {
        overlayView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {}
            overlayView = null
            windowParams = null
            containerLayout = null
            fpsTextView = null
            detailTextView = null
        }
    }

    private fun buildNotification(telemetry: FpsTelemetry, config: OverlayConfig): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Action: Toggle Floating Overlay
        val toggleOverlayIntent = Intent(this, FpsActionReceiver::class.java).apply {
            action = FpsActionReceiver.ACTION_TOGGLE_OVERLAY
        }
        val toggleOverlayPending = PendingIntent.getBroadcast(
            this, 1, toggleOverlayIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val overlayActionTitle = if (config.isOverlayEnabled) "إخفاء الزر العائم" else "إظهار الزر العائم"

        // Action: Toggle Touch-Through Lock (Click-Through)
        val toggleLockIntent = Intent(this, FpsActionReceiver::class.java).apply {
            action = FpsActionReceiver.ACTION_TOGGLE_TOUCH_LOCK
        }
        val toggleLockPending = PendingIntent.getBroadcast(
            this, 2, toggleLockIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val lockActionTitle = if (config.isTouchThroughEnabled) "🔓 فتح السحب" else "🔒 قفل وتمرير اللمس"

        // Action: Stop
        val stopIntent = Intent(this, FpsActionReceiver::class.java).apply {
            action = FpsActionReceiver.ACTION_STOP_ALL
        }
        val stopPending = PendingIntent.getBroadcast(
            this, 3, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "🎮 ${telemetry.currentFps} FPS • ${telemetry.frameTimeMs}ms (${telemetry.targetRefreshRate}Hz)"
        val content = "⚡ RAM: ${telemetry.ramUsedMb}/${telemetry.ramTotalMb}MB (${telemetry.ramUsagePercent}%) | 🔋 ${telemetry.batteryTempCelsius}°C | 1% Low: ${telemetry.low1PercentFps}"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$content\nالحالة الحرارية: ${telemetry.thermalStatus} | استقرار الفريمات: ${telemetry.fpsStabilityScore}%"))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_menu_view, overlayActionTitle, toggleOverlayPending)
            .addAction(android.R.drawable.ic_lock_lock, lockActionTitle, toggleLockPending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPending)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        collector.stop()
        telemetryJob?.cancel()
        notificationJob?.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val CHANNEL_ID = "fps_reader_monitor_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_SYNC = "com.example.fpsreader.ACTION_SYNC"
        const val ACTION_STOP = "com.example.fpsreader.ACTION_STOP"

        fun syncService(context: Context) {
            val intent = Intent(context, FpsMonitorService::class.java).apply {
                action = ACTION_SYNC
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
