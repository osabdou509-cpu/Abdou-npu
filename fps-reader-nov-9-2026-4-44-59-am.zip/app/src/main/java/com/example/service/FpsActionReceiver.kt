package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.example.data.FpsPreferences

class FpsActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val prefs = FpsPreferences.getInstance(context)

        when (action) {
            ACTION_TOGGLE_OVERLAY -> {
                val current = prefs.loadConfig().isOverlayEnabled
                prefs.setOverlayEnabled(!current)
                FpsMonitorService.syncService(context)
                val msg = if (!current) "تم تشغيل الزر العائم" else "تم إخفاء الزر العائم"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
            ACTION_TOGGLE_TOUCH_LOCK -> {
                val current = prefs.loadConfig().isTouchThroughEnabled
                prefs.setTouchThroughEnabled(!current)
                FpsMonitorService.syncService(context)
                val msg = if (!current) {
                    "تم تفعيل تمرير اللمس التام (Click-Through) للألعاب"
                } else {
                    "تم فك القفل - يمكنك الآن تحريك الزر باليد"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
            ACTION_TOGGLE_COMPACT -> {
                val current = prefs.loadConfig().isCompactMode
                prefs.setCompactMode(!current)
                FpsMonitorService.syncService(context)
            }
            ACTION_STOP_ALL -> {
                prefs.setOverlayEnabled(false)
                prefs.setNotificationEnabled(false)
                val stopIntent = Intent(context, FpsMonitorService::class.java).apply {
                    this.action = FpsMonitorService.ACTION_STOP
                }
                context.startService(stopIntent)
                Toast.makeText(context, "تم إيقاف عارض الفريمات بالكامل", Toast.LENGTH_SHORT).show()
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE_OVERLAY = "com.example.fpsreader.TOGGLE_OVERLAY"
        const val ACTION_TOGGLE_TOUCH_LOCK = "com.example.fpsreader.TOGGLE_TOUCH_LOCK"
        const val ACTION_TOGGLE_COMPACT = "com.example.fpsreader.TOGGLE_COMPACT"
        const val ACTION_STOP_ALL = "com.example.fpsreader.STOP_ALL"
    }
}
