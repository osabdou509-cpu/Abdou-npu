package com.example.monitor

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Choreographer
import android.view.Display
import com.example.model.FpsTelemetry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.ArrayDeque

class PerformanceCollector private constructor(private val context: Context) {

    private val _telemetryFlow = MutableStateFlow(FpsTelemetry())
    val telemetryFlow: StateFlow<FpsTelemetry> = _telemetryFlow.asStateFlow()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val frameTimestamps = ArrayDeque<Long>()
    private val recentDeltas = ArrayDeque<Float>()
    private val fpsHistoryList = ArrayDeque<Int>()

    private var isRunning = false
    private var lastFrameNanos: Long = 0L
    private var targetRefreshRate: Int = 60

    // Battery & RAM caching
    private var cachedBatteryTemp: Float = 34.0f
    private var cachedBatteryLevel: Int = 85
    private var cachedIsCharging: Boolean = false
    private var lastHardwarePollTime: Long = 0L

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 320)
            cachedBatteryTemp = tempTenths / 10.0f
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                cachedBatteryLevel = (level * 100) / scale
            }
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            cachedIsCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
        }
    }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isRunning) return

            // Record frame timestamp
            frameTimestamps.addLast(frameTimeNanos)

            // Remove timestamps older than 1 second (1,000,000,000 ns)
            val oneSecAgo = frameTimeNanos - 1_000_000_000L
            while (frameTimestamps.isNotEmpty() && frameTimestamps.first < oneSecAgo) {
                frameTimestamps.removeFirst()
            }

            // Delta time
            if (lastFrameNanos > 0L) {
                val deltaMs = (frameTimeNanos - lastFrameNanos) / 1_000_000.0f
                recentDeltas.addLast(deltaMs)
                if (recentDeltas.size > 120) {
                    recentDeltas.removeFirst()
                }
            }
            lastFrameNanos = frameTimeNanos

            // Calculate metrics
            val currentFps = frameTimestamps.size.coerceAtMost(targetRefreshRate + 10)
            val latestDeltaMs = if (recentDeltas.isNotEmpty()) recentDeltas.last else 16.6f

            // Calculate 1% low FPS from recent deltas
            val low1Percent = calculate1PercentLow(currentFps)

            // Poll hardware stats every 500ms to avoid overhead
            val now = System.currentTimeMillis()
            if (now - lastHardwarePollTime > 500L) {
                lastHardwarePollTime = now
                val (ramUsed, ramTotal, ramPercent) = readRamStats()
                val thermal = readThermalStatus()

                fpsHistoryList.addLast(currentFps)
                if (fpsHistoryList.size > 30) {
                    fpsHistoryList.removeFirst()
                }

                _telemetryFlow.value = FpsTelemetry(
                    currentFps = currentFps,
                    targetRefreshRate = targetRefreshRate,
                    frameTimeMs = String.format(java.util.Locale.US, "%.1f", latestDeltaMs).toFloatOrNull() ?: latestDeltaMs,
                    low1PercentFps = low1Percent,
                    avgFps = if (fpsHistoryList.isNotEmpty()) fpsHistoryList.average().toInt() else currentFps,
                    minFps = fpsHistoryList.minOrNull() ?: currentFps,
                    maxFps = fpsHistoryList.maxOrNull() ?: currentFps,
                    ramUsedMb = ramUsed,
                    ramTotalMb = ramTotal,
                    ramUsagePercent = ramPercent,
                    batteryTempCelsius = cachedBatteryTemp,
                    batteryLevel = cachedBatteryLevel,
                    isCharging = cachedIsCharging,
                    thermalStatus = thermal,
                    recentFpsHistory = fpsHistoryList.toList()
                )
            } else {
                // Quick update for FPS and frameTimeMs only
                _telemetryFlow.value = _telemetryFlow.value.copy(
                    currentFps = currentFps,
                    frameTimeMs = String.format(java.util.Locale.US, "%.1f", latestDeltaMs).toFloatOrNull() ?: latestDeltaMs,
                    low1PercentFps = low1Percent
                )
            }

            // Schedule next frame callback
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun calculate1PercentLow(fallbackFps: Int): Int {
        if (recentDeltas.size < 10) return (fallbackFps - 2).coerceAtLeast(1)
        val sortedDeltas = recentDeltas.sortedDescending() // Worst frame times first
        val index1Percent = (sortedDeltas.size * 0.05f).toInt().coerceIn(0, sortedDeltas.size - 1)
        val worstDeltaMs = sortedDeltas[index1Percent]
        return if (worstDeltaMs > 0f) {
            val lowFps = (1000f / worstDeltaMs).toInt()
            lowFps.coerceIn(1, targetRefreshRate)
        } else {
            fallbackFps
        }
    }

    private fun readRamStats(): Triple<Long, Long, Int> {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            val totalMb = memInfo.totalMem / (1024 * 1024)
            val availMb = memInfo.availMem / (1024 * 1024)
            val usedMb = (totalMb - availMb).coerceAtLeast(0)
            val percent = if (totalMb > 0) ((usedMb.toDouble() / totalMb.toDouble()) * 100).toInt() else 0
            Triple(usedMb, totalMb, percent)
        } catch (_: Exception) {
            Triple(3800L, 8192L, 46)
        }
    }

    private fun readThermalStatus(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            when (pm?.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "ممتاز (بارد)"
                PowerManager.THERMAL_STATUS_LIGHT -> "معتدل"
                PowerManager.THERMAL_STATUS_MODERATE -> "دافئ"
                PowerManager.THERMAL_STATUS_SEVERE -> "حار"
                PowerManager.THERMAL_STATUS_CRITICAL -> "حرج"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "خطر حراري"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "إيقاف"
                else -> if (cachedBatteryTemp < 37f) "بارد" else if (cachedBatteryTemp < 42f) "معتدل" else "حار"
            }
        } else {
            if (cachedBatteryTemp < 37f) "بارد" else if (cachedBatteryTemp < 42f) "معتدل" else "حار"
        }
    }

    fun start() {
        if (isRunning) return
        isRunning = true
        lastFrameNanos = 0L
        frameTimestamps.clear()
        recentDeltas.clear()

        // Read display refresh rate
        try {
            val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
            val display = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
            val hz = display?.refreshRate?.toInt() ?: 60
            targetRefreshRate = if (hz in 30..360) hz else 60
        } catch (_: Exception) {
            targetRefreshRate = 60
        }

        // Register battery monitor
        try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            context.registerReceiver(batteryReceiver, filter)
        } catch (_: Exception) {}

        // Post frame callback on main thread
        mainHandler.post {
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    fun stop() {
        if (!isRunning) return
        isRunning = false
        mainHandler.post {
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
        try {
            context.unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {}
    }

    companion object {
        @Volatile
        private var instance: PerformanceCollector? = null

        fun getInstance(context: Context): PerformanceCollector {
            return instance ?: synchronized(this) {
                instance ?: PerformanceCollector(context.applicationContext).also { instance = it }
            }
        }
    }
}
