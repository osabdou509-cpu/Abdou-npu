package com.example.ui

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LiveFpsMeter
import com.example.ui.components.NotificationControlCard
import com.example.ui.components.OverlayControlsCard
import com.example.ui.components.StressTestDialog
import com.example.ui.components.TypewriterGreeting
import com.example.ui.theme.GamerBackground
import com.example.ui.theme.GamerBorder
import com.example.ui.theme.GamerSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonLime
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: FpsViewModel
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val telemetry by viewModel.telemetryState.collectAsState()
    val config by viewModel.configState.collectAsState()
    val hasOverlayPerm by viewModel.hasOverlayPermission.collectAsState()
    val hasNotifPerm by viewModel.hasNotificationPermission.collectAsState()
    val isStressTesting by viewModel.isStressTesting.collectAsState()

    // Activity result launcher for notification permission on Android 13+
    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.checkPermissions()
        if (granted) {
            viewModel.toggleNotification(true)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.checkPermissions()
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = GamerBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gamepad,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "FPS Reader",
                            color = TextPrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = GamerBackground
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("main_screen_lazy_column"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Welcome Typewriter Greeting Card ("hi abderahmane hafsi")
            item {
                TypewriterGreeting(
                    fullText = "hi abderahmane hafsi"
                )
            }

            // 2. Quick Master Action Bar (Direct full control over show/hide for both options)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Toggle Floating Overlay
                    Button(
                        onClick = {
                            if (!hasOverlayPerm) {
                                viewModel.requestOverlayPermission(context)
                            } else {
                                viewModel.toggleOverlay(!config.isOverlayEnabled)
                                coroutineScope.launch {
                                    val msg = if (!config.isOverlayEnabled) "تم تشغيل الزر العائم" else "تم إخفاء الزر العائم"
                                    snackbarHostState.showSnackbar(msg)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_toggle_overlay_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (config.isOverlayEnabled) NeonCyan else GamerSurface,
                            contentColor = if (config.isOverlayEnabled) Color.Black else TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = if (config.isOverlayEnabled) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (config.isOverlayEnabled) "إخفاء الزر" else "إظهار الزر العائم",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    // Quick Toggle Notification Bar HUD
                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifPerm) {
                                notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                viewModel.toggleNotification(!config.isNotificationEnabled)
                                coroutineScope.launch {
                                    val msg = if (!config.isNotificationEnabled) "تم تشغيل عداد الإشعارات" else "تم إيقاف عداد الإشعارات"
                                    snackbarHostState.showSnackbar(msg)
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_toggle_notification_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (config.isNotificationEnabled) NeonLime else GamerSurface,
                            contentColor = if (config.isNotificationEnabled) Color.Black else TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (config.isNotificationEnabled) "إخفاء الإشعار" else "تفعيل شريط الإشعارات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // 3. Live Speedometer FPS Meter & Real-time Specs
            item {
                LiveFpsMeter(
                    telemetry = telemetry,
                    onLaunchStressTest = { viewModel.setStressTesting(true) }
                )
            }

            // 4. Option 1: Floating Overlay Controls Card (With Click-Through / Non-Interference Mode)
            item {
                OverlayControlsCard(
                    config = config,
                    hasOverlayPermission = hasOverlayPerm,
                    onRequestPermission = { viewModel.requestOverlayPermission(context) },
                    onToggleOverlay = { enabled ->
                        if (enabled && !hasOverlayPerm) {
                            viewModel.requestOverlayPermission(context)
                        } else {
                            viewModel.toggleOverlay(enabled)
                        }
                    },
                    onToggleTouchThrough = { viewModel.toggleTouchThrough(it) },
                    onToggleCompactMode = { viewModel.toggleCompactMode(it) },
                    onSetOpacity = { viewModel.setOpacity(it) },
                    onSetAccentColor = { viewModel.setAccentColor(it) },
                    onResetPosition = { viewModel.resetOverlayPosition() }
                )
            }

            // 5. Option 2: Notification Bar HUD Controls Card (Lightweight, Zero-Drain)
            item {
                NotificationControlCard(
                    config = config,
                    telemetry = telemetry,
                    hasNotificationPermission = hasNotifPerm,
                    onRequestPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    },
                    onToggleNotification = { enabled ->
                        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotifPerm) {
                            notifPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            viewModel.toggleNotification(enabled)
                        }
                    }
                )
            }

            // 6. Gamer Touch Protection Info Card
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF0F172A))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "حماية لمس الشاشة في ألعابك (Gamer Touch Pass-Through)",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تم تصميم الزر العائم ليعمل بتقنية FLAG_NOT_TOUCHABLE، مما يضمن أن لمسات أصابعك أثناء اللعب (مثل ألعاب التصويب والقتال) لن يتم إعاقتها أو حجبها على الإطلاق. ولتحريك الزر يمكنك فك القفل في أي وقت من التطبيق أو شريط الإشعارات.",
                                color = TextMuted,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Stress Test Modal
    if (isStressTesting) {
        StressTestDialog(
            telemetry = telemetry,
            onDismiss = { viewModel.setStressTesting(false) }
        )
    }
}
