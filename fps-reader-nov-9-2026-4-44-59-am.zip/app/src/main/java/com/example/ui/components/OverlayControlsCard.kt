package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OverlayConfig
import com.example.ui.theme.GamerBorder
import com.example.ui.theme.GamerSurface
import com.example.ui.theme.GamerSurfaceVariant
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonLime
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun OverlayControlsCard(
    config: OverlayConfig,
    hasOverlayPermission: Boolean,
    onRequestPermission: () -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onToggleTouchThrough: (Boolean) -> Unit,
    onToggleCompactMode: (Boolean) -> Unit,
    onSetOpacity: (Float) -> Unit,
    onSetAccentColor: (String) -> Unit,
    onResetPosition: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("overlay_controls_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = GamerSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (config.isOverlayEnabled) NeonCyan else GamerBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header Row: Icon + Title + Master Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(GamerSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Layers,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الزر العائم للشاشة (Floating Overlay)",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (config.isOverlayEnabled) "الزر نشط ويظهر فوق الشاشة" else "متوقف حالياً",
                            color = if (config.isOverlayEnabled) NeonLime else TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }

                Switch(
                    checked = config.isOverlayEnabled,
                    onCheckedChange = { onToggleOverlay(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color(0xFF0A0E17),
                        checkedTrackColor = NeonCyan,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = GamerBorder
                    ),
                    modifier = Modifier.testTag("toggle_overlay_switch")
                )
            }

            // Permission Warning Banner if missing
            if (!hasOverlayPermission) {
                Spacer(modifier = Modifier.height(14.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2C1E12))
                        .border(1.dp, NeonYellow.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = NeonYellow,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إذن الظهور فوق التطبيقات مطلوب",
                                color = NeonYellow,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "يلزم تفعيل إذن الظهور فوق التطبيقات الأخرى لعرض العداد فوق الألعاب بحرية.",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRequestPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = NeonYellow, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("grant_overlay_permission_button")
                        ) {
                            Text(text = "منح الإذن الآن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // CRITICAL TOUCH-THROUGH SECTION
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0B1424))
                    .border(1.dp, if (config.isTouchThroughEnabled) NeonLime.copy(alpha = 0.5f) else GamerBorder, RoundedCornerShape(14.dp))
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (config.isTouchThroughEnabled) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                tint = if (config.isTouchThroughEnabled) NeonLime else NeonYellow,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "وضع تمرير اللمس للألعاب (Click-Through)",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (config.isTouchThroughEnabled)
                                        "مفعل: اللمس يمر مباشرة للعبة ولا يؤثر على الشاشة إطلاقاً"
                                    else
                                        "غير مفعل: يمكنك الآن سحب وتحريك العداد باليد",
                                    color = if (config.isTouchThroughEnabled) NeonLime else NeonYellow,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Switch(
                            checked = config.isTouchThroughEnabled,
                            onCheckedChange = { onToggleTouchThrough(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF0A0E17),
                                checkedTrackColor = NeonLime
                            ),
                            modifier = Modifier.testTag("toggle_touch_through_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "💡 ميزة خاصة: عند تفعيل هذا الخيار، يتم إلغاء التقاط اللمس للعداد، بحيث تصل لمسات أصابعك إلى اللعبة بالكامل بدون أي انقطاع أو لمس غير مقصود.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            AnimatedVisibility(visible = config.isOverlayEnabled) {
                Column {
                    Spacer(modifier = Modifier.height(16.dp))

                    // Mode Selection: Compact vs Expanded
                    Text(
                        text = "نمط العرض فوق الشاشة:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onToggleCompactMode(true) },
                            modifier = Modifier.weight(1f).testTag("select_compact_mode"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (config.isCompactMode) NeonCyan else GamerBorder
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (config.isCompactMode) GamerSurfaceVariant else Color.Transparent
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.FitScreen,
                                contentDescription = null,
                                tint = if (config.isCompactMode) NeonCyan else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مبسط (Pill)",
                                color = if (config.isCompactMode) NeonCyan else TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        OutlinedButton(
                            onClick = { onToggleCompactMode(false) },
                            modifier = Modifier.weight(1f).testTag("select_expanded_mode"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (!config.isCompactMode) NeonCyan else GamerBorder
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (!config.isCompactMode) GamerSurfaceVariant else Color.Transparent
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = if (!config.isCompactMode) NeonCyan else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مفصل (HUD)",
                                color = if (!config.isCompactMode) NeonCyan else TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Opacity Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "شفافية العداد:",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${(config.opacity * 100).toInt()}%",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = config.opacity,
                        onValueChange = onSetOpacity,
                        valueRange = 0.3f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyan,
                            activeTrackColor = NeonCyan,
                            inactiveTrackColor = GamerBorder
                        ),
                        modifier = Modifier.testTag("opacity_slider")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Color Picker
                    Text(
                        text = "لون الإضاءة النيون:",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        listOf(
                            "CYAN" to NeonCyan,
                            "LIME" to NeonLime,
                            "RED" to NeonRed,
                            "YELLOW" to NeonYellow,
                            "PURPLE" to NeonPurple
                        ).forEach { (colorName, colorVal) ->
                            val isSelected = config.accentColor == colorName
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(colorVal)
                                    .border(
                                        2.dp,
                                        if (isSelected) Color.White else Color.Transparent,
                                        CircleShape
                                    )
                                    .clickable { onSetAccentColor(colorName) }
                                    .testTag("color_option_$colorName"),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Reset Position Button
                    OutlinedButton(
                        onClick = onResetPosition,
                        modifier = Modifier.fillMaxWidth().testTag("reset_position_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GamerBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "إعادة ضبط مكان العداد للزاوية الافتراضية", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
