package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.FpsTelemetry
import com.example.ui.theme.GamerBackground
import com.example.ui.theme.GamerBorder
import com.example.ui.theme.GamerSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonLime
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    var color: Color
)

@Composable
fun StressTestDialog(
    telemetry: FpsTelemetry,
    onDismiss: () -> Unit
) {
    var particleCount by remember { mutableIntStateOf(150) }
    val particles = remember { mutableStateListOf<Particle>() }
    var frameTick by remember { mutableFloatStateOf(0f) }

    // Initialize particles
    LaunchedEffect(particleCount) {
        particles.clear()
        val colors = listOf(NeonCyan, NeonLime, NeonYellow, NeonRed, Color(0xFFA855F7))
        repeat(particleCount) {
            particles.add(
                Particle(
                    x = Random.nextFloat() * 600f,
                    y = Random.nextFloat() * 600f,
                    vx = (Random.nextFloat() - 0.5f) * 12f,
                    vy = (Random.nextFloat() - 0.5f) * 12f,
                    radius = Random.nextFloat() * 5f + 3f,
                    color = colors.random()
                )
            )
        }
    }

    // High frequency frame loop
    LaunchedEffect(Unit) {
        while (true) {
            withFrameNanos {
                frameTick = (frameTick + 1) % 1000f
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, NeonCyan, RoundedCornerShape(24.dp))
                .testTag("stress_test_dialog"),
            color = GamerBackground
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Dialog Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختبار ضغط الفريمات المباشر",
                            color = TextPrimary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Live FPS HUD Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(GamerSurface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "الفريمات الحالية", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${telemetry.currentFps} FPS",
                            color = if (telemetry.currentFps >= telemetry.targetRefreshRate - 3) NeonLime else NeonRed,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "زمن الإطار", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${telemetry.frameTimeMs} ms",
                            color = NeonCyan,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "تردد الشاشة", color = TextSecondary, fontSize = 11.sp)
                        Text(
                            text = "${telemetry.targetRefreshRate} Hz",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Particle Simulation Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF04060A))
                        .border(1.dp, GamerBorder, RoundedCornerShape(16.dp))
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Tick read to trigger recomposition
                        val _tick = frameTick
                        val w = size.width
                        val h = size.height

                        particles.forEach { p ->
                            p.x += p.vx
                            p.y += p.vy

                            if (p.x < 0) { p.x = 0f; p.vx = -p.vx }
                            if (p.x > w) { p.x = w; p.vx = -p.vx }
                            if (p.y < 0) { p.y = 0f; p.vy = -p.vy }
                            if (p.y > h) { p.y = h; p.vy = -p.vy }

                            drawCircle(
                                color = p.color,
                                radius = p.radius,
                                center = Offset(p.x, p.y)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Particle Load Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "كثافة الجزيئات (حمل المعالجة):",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "$particleCount عنصر",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = particleCount.toFloat(),
                    onValueChange = { particleCount = it.toInt() },
                    valueRange = 50f..500f,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = GamerBorder
                    ),
                    modifier = Modifier.testTag("particle_slider")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GamerBorder, contentColor = TextPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("إنهاء الاختبار والعودة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
