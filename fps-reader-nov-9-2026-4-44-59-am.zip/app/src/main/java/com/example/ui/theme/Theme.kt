package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val GamerDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = GamerBackground,
    primaryContainer = GamerSurfaceVariant,
    onPrimaryContainer = NeonCyan,
    secondary = NeonLime,
    onSecondary = GamerBackground,
    secondaryContainer = GamerSurfaceVariant,
    onSecondaryContainer = NeonLime,
    tertiary = NeonPurple,
    background = GamerBackground,
    onBackground = TextPrimary,
    surface = GamerSurface,
    onSurface = TextPrimary,
    surfaceVariant = GamerSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = GamerBorder
)

@Composable
fun FpsReaderTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GamerDarkColorScheme,
        typography = Typography,
        content = content
    )
}
