package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FpsTelemetry
import com.example.ui.theme.GamerBorder
import com.example.ui.theme.GamerSurface
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonLime
import com.example.ui.theme.NeonRed
import com.example.ui.theme.NeonYellow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LiveFpsMeter(
    telemetry: FpsTelemetry,
    onLaunchStressTest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val targetHz = if (telemetry.targetRefreshRate > 0) telemetry.targetRefreshRate else 60
    val progress = (telemetry.currentFps.toFloat() / targetHz.toFloat()).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, animationSpec = tween(150), label = "fpsProgress")

    val gaugeColor by animateColorAsState(
        targetValue = when {
            telemetry.currentFps >= targetHz - 2 -> NeonLime
            telemetry.currentFps >= (targetHz * 0.75f) -> NeonYellow
            else -> NeonRed
        },
        animationSpec = tween(200),
        label = "gaugeColor"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(GamerSurface)
            .border(1.dp, GamerBorder, RoundedCornerShape(20.dp))
            .padding(18.dp)
            .testTag("live_fps_meter_card")
    ) {
        Column {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "عداد الفريمات المباشر",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Target Refresh Rate Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(GamerBorder)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "تردد الشاشة: ${targetHz}Hz",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Center Circular Arc Gauge & FPS Reading
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Circular Gauge
                Box(
                    modifier = Modifier.size(130.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(130.dp)) {
                        val strokeWidth = 10.dp.toPx()
                        val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
                        val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)

                        // Background track arc (240 degrees)
                        drawArc(
                            color = Color(0xFF1E293B),
                            startAngle = 150f,
                            sweepAngle = 240f,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )

                        // Active progress arc
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(NeonCyan, gaugeColor)
                            ),
                            startAngle = 150f,
                            sweepAngle = 240f * animatedProgress,
                            useCenter = false,
                            topLeft = topLeft,
                            size = arcSize,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }

                    // FPS Text Inside
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${telemetry.currentFps}",
                            color = gaugeColor,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.testTag("current_fps_text")
                        )
                        Text(
                            text = "FPS",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Side Specs (Frame Time, 1% Low, Stability)
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricMiniItem(
                        label = "زمن الإطار (Frame Time)",
                        value = "${telemetry.frameTimeMs} ms",
                        valueColor = NeonCyan
                    )
                    MetricMiniItem(
                        label = "أدنى فريمات (1% Low)",
                        value = "${telemetry.low1PercentFps} FPS",
                        valueColor = if (telemetry.low1PercentFps >= targetHz * 0.8f) NeonLime else NeonYellow
                    )
                    MetricMiniItem(
                        label = "استقرار الفريمات",
                        value = "${telemetry.fpsStabilityScore}%",
                        valueColor = NeonLime
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sparkline History Graph
            if (telemetry.recentFpsHistory.isNotEmpty()) {
                Text(
                    text = "مخطط سلاسة الفريمات (آخر 30 ثانية)",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))
                FpsSparkline(
                    history = telemetry.recentFpsHistory,
                    targetHz = targetHz,
                    lineColor = gaugeColor,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Hardware Info Chips (RAM & Battery)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // RAM Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, GamerBorder, RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("الذاكرة RAM", color = TextSecondary, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${telemetry.ramUsedMb}/${telemetry.ramTotalMb} MB (${telemetry.ramUsagePercent}%)",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (telemetry.ramUsagePercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = if (telemetry.ramUsagePercent > 85) NeonRed else NeonCyan,
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                }

                // Battery / Temp Box
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF0F172A))
                        .border(1.dp, GamerBorder, RoundedCornerShape(12.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Thermostat,
                                contentDescription = null,
                                tint = if (telemetry.batteryTempCelsius > 40f) NeonRed else NeonYellow,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("الحرارة والبطارية", color = TextSecondary, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "${telemetry.batteryTempCelsius}°C • ${telemetry.batteryLevel}%",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الحالة: ${telemetry.thermalStatus}",
                            color = NeonLime,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Stress Test Trigger Button
            Button(
                onClick = onLaunchStressTest,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("launch_stress_test_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1E293B),
                    contentColor = NeonCyan
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "اختبار ضغط واستقرار الفريمات (FPS Benchmark Test)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun MetricMiniItem(
    label: String,
    value: String,
    valueColor: Color
) {
    Column {
        Text(text = label, color = TextMuted, fontSize = 11.sp)
        Text(
            text = value,
            color = valueColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun FpsSparkline(
    history: List<Int>,
    targetHz: Int,
    lineColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF0B111E))
    ) {
        if (history.size < 2) return@Canvas

        val maxVal = (targetHz + 5).toFloat()
        val minVal = 0f
        val range = (maxVal - minVal).coerceAtLeast(1f)

        val stepX = size.width / (history.size - 1).coerceAtLeast(1)
        val path = Path()

        history.forEachIndexed { i, fpsVal ->
            val x = i * stepX
            val normalized = ((fpsVal - minVal) / range).coerceIn(0f, 1f)
            val y = size.height - (normalized * (size.height - 8.dp.toPx())) - 4.dp.toPx()

            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
