package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gaming Dark Palette
val GamerBackground = Color(0xFF0A0E17)
val GamerSurface = Color(0xFF121826)
val GamerSurfaceVariant = Color(0xFF1B2336)
val GamerBorder = Color(0xFF2B3752)

// Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonLime = Color(0xFF39FF14)
val NeonGreen = Color(0xFF10B981)
val NeonRed = Color(0xFFFF3366)
val NeonYellow = Color(0xFFFFD600)
val NeonPurple = Color(0xFFA855F7)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Material 3 mappings
val PrimaryGamer = NeonCyan
val SecondaryGamer = NeonLime
val TertiaryGamer = NeonPurple
