package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FpsPreferences
import com.example.model.FpsTelemetry
import com.example.model.OverlayConfig
import com.example.monitor.PerformanceCollector
import com.example.service.FpsMonitorService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FpsViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = FpsPreferences.getInstance(application)
    private val collector = PerformanceCollector.getInstance(application)

    val telemetryState: StateFlow<FpsTelemetry> = collector.telemetryFlow

    val configState: StateFlow<OverlayConfig> = prefs.configFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, prefs.loadConfig())

    private val _hasOverlayPermission = MutableStateFlow(false)
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _hasNotificationPermission = MutableStateFlow(true)
    val hasNotificationPermission: StateFlow<Boolean> = _hasNotificationPermission.asStateFlow()

    private val _isStressTesting = MutableStateFlow(false)
    val isStressTesting: StateFlow<Boolean> = _isStressTesting.asStateFlow()

    init {
        collector.start()
        checkPermissions()
    }

    fun checkPermissions() {
        val context = getApplication<Application>()
        _hasOverlayPermission.value = Settings.canDrawOverlays(context)

        _hasNotificationPermission.value = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun requestOverlayPermission(context: Context) {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun toggleOverlay(enabled: Boolean) {
        val context = getApplication<Application>()
        if (enabled && !Settings.canDrawOverlays(context)) {
            // Need permission
            return
        }
        prefs.setOverlayEnabled(enabled)
        FpsMonitorService.syncService(context)
    }

    fun toggleNotification(enabled: Boolean) {
        val context = getApplication<Application>()
        prefs.setNotificationEnabled(enabled)
        FpsMonitorService.syncService(context)
    }

    fun toggleTouchThrough(enabled: Boolean) {
        prefs.setTouchThroughEnabled(enabled)
        FpsMonitorService.syncService(getApplication())
    }

    fun toggleCompactMode(compact: Boolean) {
        prefs.setCompactMode(compact)
        FpsMonitorService.syncService(getApplication())
    }

    fun setOpacity(opacity: Float) {
        prefs.setOpacity(opacity)
        FpsMonitorService.syncService(getApplication())
    }

    fun setAccentColor(color: String) {
        prefs.setAccentColor(color)
        FpsMonitorService.syncService(getApplication())
    }

    fun resetOverlayPosition() {
        prefs.setPosition(80, 200)
        FpsMonitorService.syncService(getApplication())
    }

    fun setStressTesting(testing: Boolean) {
        _isStressTesting.value = testing
    }

    override fun onCleared() {
        super.onCleared()
        // If background service is not running, stop collector
        val config = prefs.loadConfig()
        if (!config.isOverlayEnabled && !config.isNotificationEnabled) {
            collector.stop()
        }
    }
}
