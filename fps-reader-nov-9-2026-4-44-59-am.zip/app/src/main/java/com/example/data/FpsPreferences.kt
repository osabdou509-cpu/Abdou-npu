package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.OverlayConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FpsPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<OverlayConfig> = _configFlow.asStateFlow()

    fun loadConfig(): OverlayConfig {
        return OverlayConfig(
            isOverlayEnabled = prefs.getBoolean(KEY_OVERLAY_ENABLED, false),
            isNotificationEnabled = prefs.getBoolean(KEY_NOTIFICATION_ENABLED, false),
            isTouchThroughEnabled = prefs.getBoolean(KEY_TOUCH_THROUGH, true),
            isCompactMode = prefs.getBoolean(KEY_COMPACT_MODE, true),
            opacity = prefs.getFloat(KEY_OPACITY, 0.95f),
            accentColor = prefs.getString(KEY_ACCENT_COLOR, "CYAN") ?: "CYAN",
            posX = prefs.getInt(KEY_POS_X, 80),
            posY = prefs.getInt(KEY_POS_Y, 200),
            isDraggingAllowed = prefs.getBoolean(KEY_DRAGGING_ALLOWED, false)
        )
    }

    fun updateConfig(update: (OverlayConfig) -> OverlayConfig) {
        val newConfig = update(_configFlow.value)
        prefs.edit().apply {
            putBoolean(KEY_OVERLAY_ENABLED, newConfig.isOverlayEnabled)
            putBoolean(KEY_NOTIFICATION_ENABLED, newConfig.isNotificationEnabled)
            putBoolean(KEY_TOUCH_THROUGH, newConfig.isTouchThroughEnabled)
            putBoolean(KEY_COMPACT_MODE, newConfig.isCompactMode)
            putFloat(KEY_OPACITY, newConfig.opacity)
            putString(KEY_ACCENT_COLOR, newConfig.accentColor)
            putInt(KEY_POS_X, newConfig.posX)
            putInt(KEY_POS_Y, newConfig.posY)
            putBoolean(KEY_DRAGGING_ALLOWED, newConfig.isDraggingAllowed)
            apply()
        }
        _configFlow.value = newConfig
    }

    fun setOverlayEnabled(enabled: Boolean) = updateConfig { it.copy(isOverlayEnabled = enabled) }
    fun setNotificationEnabled(enabled: Boolean) = updateConfig { it.copy(isNotificationEnabled = enabled) }
    fun setTouchThroughEnabled(enabled: Boolean) = updateConfig { it.copy(isTouchThroughEnabled = enabled) }
    fun setCompactMode(compact: Boolean) = updateConfig { it.copy(isCompactMode = compact) }
    fun setOpacity(opacity: Float) = updateConfig { it.copy(opacity = opacity) }
    fun setAccentColor(color: String) = updateConfig { it.copy(accentColor = color) }
    fun setPosition(x: Int, y: Int) = updateConfig { it.copy(posX = x, posY = y) }
    fun setDraggingAllowed(allowed: Boolean) = updateConfig { it.copy(isDraggingAllowed = allowed) }

    companion object {
        private const val PREFS_NAME = "fps_reader_prefs"
        private const val KEY_OVERLAY_ENABLED = "overlay_enabled"
        private const val KEY_NOTIFICATION_ENABLED = "notification_enabled"
        private const val KEY_TOUCH_THROUGH = "touch_through"
        private const val KEY_COMPACT_MODE = "compact_mode"
        private const val KEY_OPACITY = "opacity"
        private const val KEY_ACCENT_COLOR = "accent_color"
        private const val KEY_POS_X = "pos_x"
        private const val KEY_POS_Y = "pos_y"
        private const val KEY_DRAGGING_ALLOWED = "dragging_allowed"

        @Volatile
        private var instance: FpsPreferences? = null

        fun getInstance(context: Context): FpsPreferences {
            return instance ?: synchronized(this) {
                instance ?: FpsPreferences(context.applicationContext).also { instance = it }
            }
        }
    }
}
