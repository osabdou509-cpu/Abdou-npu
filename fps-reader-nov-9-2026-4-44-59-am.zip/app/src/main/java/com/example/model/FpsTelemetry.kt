package com.example.model

/**
 * Real-time performance telemetry data for games and system monitoring.
 */
data class FpsTelemetry(
    val currentFps: Int = 60,
    val targetRefreshRate: Int = 60,
    val frameTimeMs: Float = 16.6f,
    val low1PercentFps: Int = 58,
    val avgFps: Int = 60,
    val minFps: Int = 55,
    val maxFps: Int = 60,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val ramUsagePercent: Int = 0,
    val batteryTempCelsius: Float = 0f,
    val batteryLevel: Int = 0,
    val isCharging: Boolean = false,
    val thermalStatus: String = "طبيعي",
    val recentFpsHistory: List<Int> = emptyList()
) {
    val fpsStabilityScore: Int
        get() {
            if (targetRefreshRate <= 0) return 100
            val ratio = (currentFps.toFloat() / targetRefreshRate.toFloat()) * 100f
            return ratio.toInt().coerceIn(0, 100)
        }
}

/**
 * Overlay settings and configuration.
 */
data class OverlayConfig(
    val isOverlayEnabled: Boolean = false,
    val isNotificationEnabled: Boolean = false,
    val isTouchThroughEnabled: Boolean = true, // When true, passes all touches directly to games
    val isCompactMode: Boolean = true, // Compact pill (FPS only) vs Expanded HUD
    val opacity: Float = 0.95f,
    val accentColor: String = "CYAN", // CYAN, GREEN, RED, YELLOW, PURPLE
    val posX: Int = 100,
    val posY: Int = 200,
    val isDraggingAllowed: Boolean = true // When true and not in touch-through, allows moving
)
