package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("FPS Reader", appName)
  }

  @Test
  fun `test default preferences and stability score`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = com.example.data.FpsPreferences.getInstance(context)
    val config = prefs.loadConfig()
    // Touch through should be enabled by default for gaming safety
    org.junit.Assert.assertTrue(config.isTouchThroughEnabled)

    val telemetry = com.example.model.FpsTelemetry(
      currentFps = 60,
      targetRefreshRate = 60
    )
    assertEquals(100, telemetry.fpsStabilityScore)
  }
}
